import React from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import './index.css';

function App() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">WorkSync Calendar</h1>
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin]}
        initialView="dayGridMonth"
        headerToolbar={{
          start: 'prev,next today',
          center: 'title',
          end: 'dayGridMonth,timeGridWeek,timeGridDay'
        }}
        events={[
          { title: 'Shared Meeting', date: '2025-07-28' },
        ]}
      />
    </div>
  );
}

export default App;